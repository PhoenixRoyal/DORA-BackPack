﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GtkCodeView;
using BackpackAPI;

namespace $safeprojectname$
{
    class Plugin : IPlugin
    {
        public string Author
        {
            get { return "Author"; }
        }

        public string Description
        {
            get { return "Description"; }
        }

        public void Init(IPluginContext c)
        {

        }

        public string Name
        {
            get { return "Name"; }
        }

        public void Unload()
        {

        }

        public string Version
        {
            get { return "1.0"; }
        }
    }
}
